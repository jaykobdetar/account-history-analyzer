# Supplied account-history measurements

**Privacy:** This report contains source text and identifiers.

Snapshot: empty&#95;snapshot&#95;v1. Source category: synthetic. All temporal labels use UTC.

[Coverage](#coverage) · [Text](#text) · [Activity](#activity) · [Reuse](#reuse) · [Comparisons](#style) · [Candidates](#changes) · [Links](#links) · [Evidence](#evidence) · [Methods](#methods)

<a id="coverage"></a>

## Coverage and limitations

Module status: **insufficient&#95;data**. Reasons: empty&#95;snapshot.

- These are measurements of supplied records. Coverage and language are supplier declarations.
- A measured pattern does not establish its cause. Style distance is not an authorship probability.
- A content match does not establish deceptive intent. A timestamp gap does not establish sleep or inactivity.
- Observed text is ordered by record creation time; edited wording may differ from wording at creation.
- AI text detection: not_implemented_in_v1. Real-world validation: not_established.

Unique supplied records: **0**. Usable body texts: 0. Missing creation times: 0.
Coverage declaration: **complete&#95;for&#95;declared&#95;scope**; not independently verified. Declared range: not supplied to not supplied.

| Supplied text status | Distinct records |
| --- | --- |
| present | 0 |
| deleted | 0 |
| removed | 0 |
| unavailable | 0 |

| Declared language | Records |
| --- | --- |


<a id="text"></a>

## Direct text measurements

Module status: **insufficient&#95;data**. Reasons: no&#95;usable&#95;text.

### Retained body prose

Included records: 0; usable text observations: 0. Rates pool counts before dividing.

| Measurement | Count |
| --- | --- |
| Retained word tokens | 0 |
| Number tokens | 0 |
| Retained Unicode code points | 0 |
| Cased code points | 0 |
| Uppercase code points | 0 |
| Retained boundary-separated segments | 0 |
| Retained prose blocks | 0 |
| Alphabetic code points inside word tokens | 0 |
| Removed explicit quote spans | 0 |
| Removed code spans | 0 |
| Removed visible URL spans | 0 |
| Source headings | 0 |
| Source list items | 0 |
| Detected source link occurrences | 0 |
| Excluded mentions | 0 |

Uppercase fraction = uppercase / cased code points: **not computable**. Average word length = alphabetic code points / retained word tokens: **not computable**.
Undefined rates: zero&#95;cased&#95;letters&#95;denominator, zero&#95;retained&#95;codepoints&#95;denominator, zero&#95;retained&#95;words&#95;denominator.

Retained words per usable record (n=0): min not computable, Q1 not computable, median not computable, Q3 not computable, max not computable. Quantiles use linear interpolation at (n−1)q.

<details><summary>Literal punctuation and lexical descriptors</summary>

| Literal punctuation | Count | Per 1,000 word tokens | Per 1,000 retained code points |
| --- | --- | --- | --- |
| ascii apostrophe | 0 | not computable | not computable |
| ascii double quote | 0 | not computable | not computable |
| ascii hyphen | 0 | not computable | not computable |
| ascii period runs | 0 | not computable | not computable |
| colon | 0 | not computable | not computable |
| comma | 0 | not computable | not computable |
| curly apostrophe | 0 | not computable | not computable |
| ellipsis | 0 | not computable | not computable |
| em dash | 0 | not computable | not computable |
| en dash | 0 | not computable | not computable |
| exclamation mark | 0 | not computable | not computable |
| left curly double quote | 0 | not computable | not computable |
| period | 0 | not computable | not computable |
| question mark | 0 | not computable | not computable |
| right curly double quote | 0 | not computable | not computable |
| semicolon | 0 | not computable | not computable |

ASCII period runs overlap literal period counts; these are not disjoint quantities.
Standalone literal i/I token counts: 0/0. These are not verified pronoun labels.
English-specific denominator: 0 retained words in 0 declared-English usable records.

| Literal alternative | Contracted | Expanded | Opportunities | Qualified fraction | Status |
| --- | --- | --- | --- | --- | --- |
| dont&#95;do&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| doesnt&#95;does&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| didnt&#95;did&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| isnt&#95;is&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| arent&#95;are&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| wasnt&#95;was&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| werent&#95;were&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| couldnt&#95;could&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| shouldnt&#95;should&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| wouldnt&#95;would&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| wont&#95;will&#95;not | not computable | not computable | not computable | not computable | not&#95;run |
| im&#95;i&#95;am | not computable | not computable | not computable | not computable | not&#95;run |
| ive&#95;i&#95;have | not computable | not computable | not computable | not computable | not&#95;run |
| youre&#95;you&#95;are | not computable | not computable | not computable | not computable | not&#95;run |
| were&#95;we&#95;are | not computable | not computable | not computable | not computable | not&#95;run |
| theyre&#95;they&#95;are | not computable | not computable | not computable | not computable | not&#95;run |

Raw fractions below the opportunity guard remain in the numerical export; they are not displayed as qualified preferences.

</details>

### Submission titles (separate scope)

Included records: 0; usable text observations: 0. Rates pool counts before dividing.

| Measurement | Count |
| --- | --- |
| Retained word tokens | 0 |
| Number tokens | 0 |
| Retained Unicode code points | 0 |
| Cased code points | 0 |
| Uppercase code points | 0 |
| Retained boundary-separated segments | 0 |
| Retained prose blocks | 0 |
| Alphabetic code points inside word tokens | 0 |
| Removed explicit quote spans | 0 |
| Removed code spans | 0 |
| Removed visible URL spans | 0 |
| Source headings | 0 |
| Source list items | 0 |
| Detected source link occurrences | 0 |
| Excluded mentions | 0 |

Uppercase fraction = uppercase / cased code points: **not computable**. Average word length = alphabetic code points / retained word tokens: **not computable**.
Undefined rates: zero&#95;cased&#95;letters&#95;denominator, zero&#95;retained&#95;codepoints&#95;denominator, zero&#95;retained&#95;words&#95;denominator.

Retained words per usable record (n=0): min not computable, Q1 not computable, median not computable, Q3 not computable, max not computable. Quantiles use linear interpolation at (n−1)q.

<a id="activity"></a>

## Observed supplied activity

Module status: **insufficient&#95;data**. Reasons: no&#95;supplied&#95;timestamps.

Distinct timed supplied events: **0**, including records whose text is deleted, removed or unusable. Range: not supplied to not supplied.
Observed span: not computable seconds. Event-bearing UTC dates: 0 of 0 calendar dates; dates with no supplied events: 0.
Zero-event dates and long gaps do not establish inactivity or sleep. Hour bins aggregate across dates.

<!-- AHAS_CHART:activity_daily.svg -->
![Observed events per UTC calendar date](activity_daily.svg)

<!-- AHAS_CHART:activity_hourly.svg -->
![Observed events in UTC hour bins across all dates](activity_hourly.svg)

| Adjacent-event gap summary | Value |
| --- | --- |
| Interval count | 0 |
| Mean / median (seconds) | not computable / not computable |
| Q1 / Q3 (seconds) | not computable / not computable |
| Population variance (seconds squared) | not computable |
| Population SD / mean (dimensionless) | not computable |
| Variability missingness reason | fewer&#95;than&#95;two&#95;intervals |

| Inclusive sliding duration (seconds) | Maximum supplied events | Witness source records |
| --- | --- | --- |
| 30 | 0 | none supplied |
| 120 | 0 | none supplied |
| 3600 | 0 | none supplied |

Greedy nonoverlapping fixed-window bursts: 0; duration 30 seconds, minimum 3 events. This differs from gap-connected sessions or overlapping sliding counts.


<details><summary>Weekday exposure and simultaneous supplied timestamps</summary>

| UTC weekday | Calendar dates in supplied range | Supplied events |
| --- | --- | --- |
| Monday | 0 | 0 |
| Tuesday | 0 | 0 |
| Wednesday | 0 | 0 |
| Thursday | 0 | 0 |
| Friday | 0 | 0 |
| Saturday | 0 | 0 |
| Sunday | 0 | 0 |


</details>

<a id="reuse"></a>

## Content reuse and source evidence

Module status: **insufficient&#95;data**. Reasons: no&#95;comparable&#95;reuse&#95;text.

Exact equivalence groups: 0. Qualifying shingle pairs: 0. Candidate pairs checked: 0; budget 2000000; complete near-reuse search: true.
Raw strings, normalized prose and lexical token sequences are different match types. Empty/sentinel text is excluded. Short common text is excluded from substantial-reuse findings.
Shingles are sets of consecutive tokens within segments. Jaccard divides shared shingles by their union; directed containment divides by the source side’s shingle count. Exact rational thresholds are recorded in resolved_config.json.

| Exact match type | Source records | Scope qualification |
| --- | --- | --- |

Showing 0 of 0 exact groups; 0 omitted from this preview. All groups are in results.json.

| Source pair | Words left/right | Shared / union shingles | Jaccard | Left in right | Right in left |
| --- | --- | --- | --- | --- | --- |

Showing 0 of 0 pairs; 0 omitted from this preview. Complete computed pairs and passages are in results.json.
Connected reuse groups: 0. Connected edges do not assert pairwise equivalence among every group member.
A shared shingle set is not necessarily one contiguous passage. Lexically matched source passages may retain different case and punctuation.


<a id="style"></a>

## Writing windows and descriptive comparisons

Module status: **insufficient&#95;data**. Reasons: insufficient&#95;comparable&#95;text.

Windows contain whole records, with separate comment and submission-body streams. A visible final remainder is excluded from segmentation. Community streams share records with pooled streams and are not independent samples.

| Stream scope | Target words / min records | Eligible words | Qualified windows | Remainder words |
| --- | --- | --- | --- | --- |
| pooled comment | 1000 / 8 | 0 | 0 | 0 |
| pooled submission | 1000 / 8 | 0 | 0 | 0 |

<!-- AHAS_CHART:eligible_word_volume.svg -->
![Retained words in primary pooled writing windows](eligible_word_volume.svg)

Showing 0 of 0 comparisons; 0 omitted from this preview. Complete comparisons/contributions are in results.json and all memberships in windows.jsonl.
Raw measurements may be computable below the qualified sample guard. A distance is not a percentage of different authorship, and raw/masked distance scales are not interchangeable.

The preview prioritizes manual selections, then candidate-adjacent comparisons, then other comparisons in export order.

<a id="changes"></a>

## Descriptive change candidates and sensitivity

Timeline: observed text ordered by record creation time. A candidate locates a boundary between measured windows, not an exact event date, a cause, or a change of author.

**pooled comment: insufficient&#95;data.** 0 qualified windows; λ=1, β=not computable; segment SSE=not computable; total penalized objective=not computable.
Optimizer: pelt&#95;l2&#95;min&#95;size&#95;safe&#95;pruning&#95;v1; min segment 3 windows; jump 1. Reasons: fewer&#95;than&#95;required&#95;qualified&#95;windows.

**pooled submission: insufficient&#95;data.** 0 qualified windows; λ=1, β=not computable; segment SSE=not computable; total penalized objective=not computable.
Optimizer: pelt&#95;l2&#95;min&#95;size&#95;safe&#95;pruning&#95;v1; min segment 3 windows; jump 1. Reasons: fewer&#95;than&#95;required&#95;qualified&#95;windows.

<!-- AHAS_CHART:surface_features.svg -->
![Selected pooled surface feature trajectories and descriptive candidates](surface_features.svg)

<!-- AHAS_CHART:adjacent_distances.svg -->
![Adjacent primary-window raw masked and function-word distances](adjacent_distances.svg)

### Predefined sensitivity settings

Stability across settings is not confidence. Constant no-variation measurements count as executed settings; insufficient settings are excluded from the denominator. Different window constructions use original record-order intervals. Endpoint touching is distinguished from interior overlap.

- pooled comment: 0 settings executed, 4 skipped.
- pooled submission: 0 settings executed, 4 skipped.

<details><summary>Alternative constructions, exclusions and interval relationships</summary>

**window&#95;target**, target 500 words: insufficient&#95;data. Excluded records: none supplied. Reasons: no&#95;qualified&#95;streams.

Stream pooled comment: not&#95;comparable; 0 primary and 0 setting boundaries.
Stream pooled submission: not&#95;comparable; 0 primary and 0 setting boundaries.

**window&#95;target**, target 2000 words: insufficient&#95;data. Excluded records: none supplied. Reasons: no&#95;qualified&#95;streams.

Stream pooled comment: not&#95;comparable; 0 primary and 0 setting boundaries.
Stream pooled submission: not&#95;comparable; 0 primary and 0 setting boundaries.

**exclude&#95;known&#95;edited**, target 1000 words: insufficient&#95;data. Excluded records: none supplied. Reasons: no&#95;qualified&#95;streams.

Stream pooled comment: not&#95;comparable; 0 primary and 0 setting boundaries.
Stream pooled submission: not&#95;comparable; 0 primary and 0 setting boundaries.

**repeat&#95;reduced&#95;exact**, target 1000 words: insufficient&#95;data. Excluded records: none supplied. Reasons: no&#95;qualified&#95;streams.

Stream pooled comment: not&#95;comparable; 0 primary and 0 setting boundaries.
Stream pooled submission: not&#95;comparable; 0 primary and 0 setting boundaries.

**repeat&#95;reduced&#95;near**, target 1000 words: not&#95;run. Excluded records: none supplied. Reasons: disabled&#95;by&#95;configuration.


Within-community control: insufficient&#95;data. Reasons: no&#95;qualified&#95;community&#95;streams.
Alternative target/exclusion runs use pooled streams; community controls use primary community streams. Known edits are excluded only in that sensitivity view; unknown edits remain unknown. Repeat reduction does not change primary text or activity.

</details>

<a id="links"></a>

## Linked-host observations

Module status: **insufficient&#95;data**. Reasons: empty&#95;snapshot.

Detected link occurrences: 0; valid HTTP(S): 0; malformed: 0; unsafe schemes: 0.
Records with a valid link: 0 of 0 (not computable fraction). Distinct normalized hosts: 0.
Hostnames are parsed locally, with no fetching or DNS. They are not registrable domains. Link repetition does not establish advertising, payment or intent.

| Hostname | Occurrences | Records with host / supplied records | Fraction of records | Fraction of valid HTTP(S) links | Sources |
| --- | --- | --- | --- | --- | --- |

<details><summary>Host distributions by community and writing windows, including sensitivity</summary>


</details>

<a id="interactions"></a>

## Supplied interaction structure

Module status: **insufficient&#95;data**. Reasons: empty&#95;snapshot.

Parent/thread context is limited to supplied metadata. Creation-to-parent-creation delay is **not typing time or read-to-reply time**. Missing parents do not establish evasion.

| Supplied thread | Records | Replies | Repeat participation | Source records |
| --- | --- | --- | --- | --- |

| Reply record | Supplied parent | Creation-to-parent-creation seconds | Timestamp source | Status / reason |
| --- | --- | --- | --- | --- |

Showing 0 of 0 parent-difference rows; 0 omitted from this preview. Complete supplied-context observations remain in results.json.

<details><summary>Transitions across supplied community labels</summary>

Transitions describe consecutive supplied timed records; intervening uncollected events are unknown.

<pre>{
  &quot;adjacent_pairs&quot;: 0,
  &quot;changed_label_count&quot;: 0,
  &quot;timestamped_record_count&quot;: 0,
  &quot;transition_counts&quot;: [],
  &quot;transitions&quot;: []
}</pre>

</details>

<a id="evidence"></a>

## Evidence catalogue

0 evidence objects. Each example is an actual supplied raw-source or stored normalized-segment slice. Offsets labeled normalized_segment are not raw-source offsets.
Feature-rate examples show selected high-rate records; ordinary_context is background context, not feature proof.

<a id="sources"></a>

## Source reference index

Only actual supplied record IDs referenced in this report appear here. Full records/features are in the input snapshot and records_features.jsonl; this index does not claim complete context.

<a id="methods"></a>

## Methods, parameters and reproducibility

All narrative sentences are fixed templates. Measurements come from results.json and windows.jsonl. Full expanded parameters are in [resolved_config.json](resolved_config.json), feature formulas and evidence rules in [method_registry.json](method_registry.json), and complete source evidence in evidence.jsonl from the analysis directory.
Established primitives are separated from project adaptations. Published classification accuracy from the research below does not transfer to this descriptive pipeline.

| Method | Registered calculation or limitation | Source references |
| --- | --- | --- |
| Character profiles / cosine | Configured within-segment case-sensitive character n-grams; cosine abstains on a zero norm. | S1, S7 |
| Fixed English profiles / JS | Project vocabulary plus OTHER_WORD; square-root Jensen–Shannon with base 2 and no smoothing. | S3, S8 |
| function_mask_v1 | Project adaptation retaining fixed-list function words; length/punctuation information remains. | S2 |
| Classic Delta | Frozen reference; compatible per-1,000-word units; SD ≤ 1e-12 excluded. Missing reference means not run. | S4 |
| Exact reuse / configured token shingles | Separate equivalence relations; exact set Jaccard and directed containment; integer threshold decisions. | S9 |
| Temporal candidates | Account-local population scaling and family weights; L2 plus β per internal boundary. | S5, S6 |
| Production PELT adaptation | pelt_l2_min_size_safe_pruning_v1 delays pruning until a witness split can form a legal minimum-size segment. | S5, S6 |
| Canonical artifacts | Sorted finite UTF-8 JSON, fixed resources and environment; operational receipts are separate. | S12, S13 |
| Evaluation status | Numerical/synthetic engineering checks are distinct from unavailable real-world validation. | S10, S11, S15 |

The corrected PELT control flow addresses a tested early-pruning failure in the pinned upstream implementation when minimum segment length exceeds one. The penalized objective is unchanged; the adaptation is explicitly named and tested against independent small-sequence oracles.
Same-window sensitivity maximizes one-to-one matches, then minimizes displacement, then resolves lexicographic ties. Different constructions compare boundary intervals. No p-values, significance stars or confidence probabilities are produced.

- [S1: Character n-gram research](https://aclanthology.org/N15-1010/)
- [S2: Text distortion research](https://aclanthology.org/E17-1107/)
- [S3: Function-word research](https://aclanthology.org/W14-0908/)
- [S4: Classic Delta implementations](https://journal.r-project.org/articles/RJ-2016-007/)
- [S5: PELT optimization](https://arxiv.org/abs/1101.1438)
- [S6: ruptures PELT documentation](https://centre-borelli.github.io/ruptures-docs/user-guide/detection/pelt/)
- [S7: SciPy cosine distance](https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.distance.cosine.html)
- [S8: SciPy Jensen–Shannon distance](https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.distance.jensenshannon.html)
- [S9: Shingle resemblance and containment](https://www.cs.princeton.edu/courses/archive/spr05/cos598E/bib/broder97resemblance.pdf)
- [S10: Evaluation leakage guidance](https://scikit-learn.org/stable/common_pitfalls.html)
- [S11: RAID detector evaluation cautions](https://aclanthology.org/2024.acl-long.674/)
- [S12: Python 3.12 UTC datetime](https://docs.python.org/3.12/library/datetime.html)
- [S13: Python 3.12 JSON serialization](https://docs.python.org/3.12/library/json.html)
- [S14: CommonMark parsing](https://spec.commonmark.org/0.31.2/)
- [S15: PAN writing-style task scope](https://pan.webis.de/clef25/pan25-web/style-change-detection.html)

- Suite version: 1.0.0; report template: 1.0.0.
- Canonical snapshot SHA-256: `cdedbaeae84666828d12edf785e0c7b0a0c086cebc33898258e72e24edd06573`
- Expanded configuration SHA-256: `6094552280274839bb5fd9c872def461dfd9ad311eb6cde28b4d9a342adf1e06`
- Implementation fingerprint: `e4c53004244b72b117d1ad900a3b76afa1ecc5a0f4b0a5fa62930e92a04f83a0`
- Numerical environment: CPython-3.12.3;Linux;x86&#95;64;numpy=2.4.2;scipy=1.17.1;ruptures=1.1.10;markdown-it-py=3.0.0;jsonschema=4.26.0

Hashes establish correspondence with supplied bytes, not authenticity or authorship. Byte identity is claimed only for environments actually tested. Runtime, host and raw-file receipts are separate from canonical measurements.

<details><summary>Frozen resource hashes</summary>

| Resource | SHA-256 |
| --- | --- |
| contraction&#95;pairs.json | f14da203d3a5965b5ea0982551dc9748c4a9655e7662cf8617ba58d86b805f34 |
| default.toml | e860a1d89ae4d65bc639b055c2320fa7f57a4cadacf693de2fc393dedd2d5608 |
| function&#95;words&#95;en&#95;v1.txt | f91c30201a636e7a9edd15166342afdcedae7fa34d7c7dd5c7352e49d4af2c9e |
| method&#95;registry | 32fa769d49ce7179a1a0ac3bc734e9fc6e5395859dce41fb8dd7cd932c51a5ee |
| report&#95;templates | d7126dadd4a2c64ece326a906f4e063c7ffe8162956fdaeedd54e7f323d76740 |

</details>
