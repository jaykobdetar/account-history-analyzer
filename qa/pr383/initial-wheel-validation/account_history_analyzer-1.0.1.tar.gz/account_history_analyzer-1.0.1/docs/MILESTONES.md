# Implementation checklist

- [x] M0: strict contracts, defaults, canonical IO, validation CLI; ingestion gates.
- [x] M1: retained text, counts, activity, first actual JSON/Markdown report; arithmetic gates.
- [x] M2: exact/shingle reuse, evidence, deweighting, explicit budgets; reuse oracles.
- [x] M3: representations, distances, reference-guarded Delta, windows/manual slices; numerical gates.
- [x] M4: family scaling, PELT, boundary mapping and sensitivity; exhaustive oracle gates.
- [x] M5: full safe HTML/Markdown/charts, links/structure, render privacy, verification.
- [x] M6: offline evaluation, process reproducibility, measured performance, locked release.

Prior milestone gates must pass before implementation of the next milestone.
Actual commands/outcomes are recorded in EVALUATION.md. Scientific validation is separate.

## Focused PR #383 update

- [x] Verify immutable baseline and actual PR source/commit/license.
- [x] Pass prior numerical gate before replacing the optimizer.
- [x] Backport exact method; update wrapper, registry, schemas and provenance.
- [ ] Pass independent/upstream/full offline tests and synthetic evaluator.
- [ ] Measure performance and separate-process canonical reproducibility.
- [ ] Build/install/package update and record new reports without rewriting baseline receipts.
