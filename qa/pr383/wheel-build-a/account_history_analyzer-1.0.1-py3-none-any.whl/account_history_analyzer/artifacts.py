"""Atomic artifact publication and independent integrity checking."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping
import os
import platform
import resource
import shutil
import tempfile
import time

from .errors import InputError, IntegrityError
from .io import Snapshot, canonical_bytes, digest, freeze, load_json, sha256_bytes, thaw


@dataclass(frozen=True)
class AnalysisResult:
    """Immutable complete in-memory analysis and named deterministic artifacts.

    `receipt` is operational and excluded from canonical identity. Normal missing
    data stays in module statuses; resource limits produce a partial result.
    """
    results: Mapping[str, Any]
    files: Mapping[str, bytes]
    ingest_receipt: Mapping[str, Any]
    run_receipt: Mapping[str, Any]
    exit_code: int = 0


def jsonl_bytes(rows: list | tuple) -> bytes:
    return b''.join(canonical_bytes(row) for row in rows)


def publish_files(files: Mapping[str, bytes], output_dir: str | Path, *, overwrite: bool = False) -> None:
    """Stage a complete directory then rename; never publish a success marker early.

    Existing nonempty directories require explicit overwrite. A symlink target is
    rejected. Artifact names must be single fixed basenames, never supplied IDs.
    """
    out = Path(output_dir).absolute()
    if any(p.is_symlink() for p in (out, *out.parents)):
        raise InputError('Output directory and ancestors must not be symlinks', code='unsafe_output_path')
    out = out.resolve()
    current = Path.cwd().resolve()
    if out == Path(out.anchor) or out == current or out in current.parents:
        raise InputError('Output must be a dedicated directory', code='unsafe_output_path')
    if out.exists() and not out.is_dir():
        raise InputError('Output path is not a directory', code='unsafe_output_path')
    if out.exists() and any(out.iterdir()) and not overwrite:
        raise InputError('Output directory is nonempty; use --overwrite', code='output_exists')
    for name in files:
        if Path(name).name != name or name in {'.', '..'} or '\\' in name:
            raise InputError('Artifact name is not a safe basename', code='unsafe_artifact_path')
    out.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.ahas-staging-', dir=out.parent))
    backup: Path | None = None
    try:
        for name, data in sorted(files.items(), key=lambda item: (item[0] == 'checksums.json', item[0])):
            with (staging / name).open('xb') as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
        if out.exists():
            backup = Path(tempfile.mkdtemp(prefix='.ahas-previous-', dir=out.parent))
            backup.rmdir()
            out.rename(backup)
        staging.rename(out)
    except BaseException:
        if backup is not None and backup.exists() and not out.exists():
            backup.rename(out)
        raise
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    if backup is not None:
        shutil.rmtree(backup)


def write_artifacts(result: AnalysisResult, output_dir: str | Path, *, overwrite: bool = False) -> None:
    """Write a complete analysis atomically; operational receipts are separate."""
    from .reporting import render_markdown, render_html
    from .charts import render_charts
    files = dict(result.files)
    files['results.json'] = canonical_bytes(result.results)
    evidence = [__import__('json').loads(line) for line in files['evidence.jsonl'].splitlines()]
    windows = [__import__('json').loads(line) for line in files['windows.jsonl'].splitlines()]
    files.update(render_charts(thaw(result.results), windows))
    excerpt_mode = thaw(result.run_receipt).get('render_excerpts', 'included')
    md = render_markdown(thaw(result.results), evidence, excerpts=excerpt_mode, windows=windows)
    files['report.md'] = md.encode('utf-8')
    files['report.html'] = render_html(thaw(result.results), evidence, excerpts=excerpt_mode, windows=windows).encode('utf-8')
    files['checksums.json'] = canonical_bytes({name: sha256_bytes(data) for name, data in sorted(files.items())})
    files['ingest_receipt.json'] = canonical_bytes(result.ingest_receipt)
    files['run_receipt.json'] = canonical_bytes(result.run_receipt)
    publish_files(files, output_dir, overwrite=overwrite)


def safe_artifact(directory: Path, name: str) -> Path:
    if not isinstance(name, str) or Path(name).name != name or '\\' in name or name in {'.', '..'}:
        raise IntegrityError('Unsafe artifact path', code='unsafe_artifact_path')
    path = directory / name
    if path.is_symlink() or not path.is_file() or path.resolve().parent != directory.resolve():
        raise IntegrityError(f'Missing/unsafe artifact {name}', code='missing_artifact')
    return path


def verify_artifacts(directory: str | Path, snapshot: Snapshot | None = None) -> dict[str, Any]:
    """Check local checksums and supplied snapshot identity; this is integrity only."""
    from .schemas import validate
    root = Path(directory)
    checks = load_json(safe_artifact(root, 'checksums.json'))
    if not isinstance(checks, dict) or not {'results.json', 'resolved_config.json', 'records_features.jsonl', 'windows.jsonl', 'evidence.jsonl', 'report.md', 'report.html'} <= checks.keys():
        raise IntegrityError('Incomplete checksum manifest', code='incomplete_artifacts')
    for name, expected in sorted(checks.items()):
        if sha256_bytes(safe_artifact(root, name).read_bytes()) != expected:
            raise IntegrityError(f'Artifact checksum mismatch: {name}', code='artifact_mismatch')
    result = load_json(safe_artifact(root, 'results.json'))
    validate(result, 'results', location='results')
    for name, meta in sorted(result['artifacts'].items()):
        if sha256_bytes(safe_artifact(root, meta['relative_path']).read_bytes()) != meta['sha256']:
            raise IntegrityError(f'Result artifact mismatch: {name}', code='artifact_mismatch')
    if digest(load_json(safe_artifact(root, 'resolved_config.json'))) != result['analysis']['config_sha256']:
        raise IntegrityError('Configuration identity mismatch', code='config_mismatch')
    if snapshot is not None and snapshot.canonical_sha256 != result['snapshot']['canonical_sha256']:
        raise IntegrityError('Supplied snapshot mismatch', code='snapshot_mismatch')
    return {'status': 'integrity_only', 'checked_artifacts': len(checks),
            'results_sha256': sha256_bytes((root/'results.json').read_bytes())}
