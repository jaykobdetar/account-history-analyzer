"""Integrity and explicit recomputation, without trusting receipt resource paths."""
from __future__ import annotations
from pathlib import Path
from typing import Any
from .artifacts import safe_artifact, verify_artifacts
from .config import AnalysisConfig, resource_bytes
from .errors import InputError, IntegrityError
from .io import canonical_bytes, digest, load_json, load_snapshot, sha256_bytes, thaw


def config_from_resolved(directory: str | Path) -> tuple[AnalysisConfig, dict | None]:
    """Reconstruct settings using verified bundled identities and local artifact reference.

    Operational receipt paths are never used to read arbitrary resources during
    replay. External references are restored from the verified analysis directory.
    """
    root = Path(directory)
    resolved = load_json(safe_artifact(root, 'resolved_config.json'))
    selection = resolved.pop('manual_selection', None)
    for name in ('function_words_resource', 'contraction_pairs_resource'):
        identity = resolved['text'][name]
        if sha256_bytes(resource_bytes(identity['resource_id'])) != identity['sha256']:
            raise IntegrityError('Installed bundled resource differs from analyzed resource', code='resource_mismatch')
        resolved['text'][name] = identity['resource_id']
    reference = resolved['delta']['reference_path']
    if reference is None:
        resolved['delta']['reference_path'] = ''
    else:
        path = safe_artifact(root, 'delta_reference.json')
        if sha256_bytes(path.read_bytes()) != reference['sha256']:
            raise IntegrityError('Frozen reference digest mismatch', code='reference_mismatch')
        resolved['delta']['reference_path'] = str(path.resolve())
    return AnalysisConfig.from_mapping(resolved), selection


def verify(input_path: str | Path, manifest_path: str | Path, analysis_dir: str | Path,
           *, recompute: bool = False, config_path: str | Path | None = None) -> dict[str, Any]:
    """Verify artifact and snapshot identities; recompute only when explicitly requested."""
    try:
        checked = verify_artifacts(analysis_dir)
        stored_config, selection = config_from_resolved(analysis_dir)
        config = AnalysisConfig.from_toml(config_path) if config_path else stored_config
        expected = load_json(Path(analysis_dir)/'results.json')
        analytical = config.analytical()
        if selection is not None:
            analytical['manual_selection'] = selection
        if digest(analytical) != expected['analysis']['config_sha256']:
            raise IntegrityError('Expanded configuration mismatch', code='config_mismatch')
        snapshot = load_snapshot(input_path, manifest_path, config)
        if snapshot.canonical_sha256 != expected['snapshot']['canonical_sha256']:
            raise IntegrityError('Supplied canonical snapshot mismatch', code='snapshot_mismatch')
        if recompute:
            from .pipeline import analyze
            rerun = analyze(snapshot, config, selection=selection)
            if canonical_bytes(rerun.results) != (Path(analysis_dir)/'results.json').read_bytes():
                raise IntegrityError('Recomputed canonical result differs; inspect implementation/environment/config identities', code='reproduction_mismatch')
            checked['status'] = 'reproduced'
        return checked
    except (InputError, KeyError, TypeError, ValueError, OSError) as exc:
        raise IntegrityError(f'Invalid verification input: {exc}', code='invalid_verification_input') from exc
